class Employee {
  constructor(name, sal, deptId) {
    this.name = name;
    this.sal = sal;
    this.department = { "deptId": deptId};
  }
}

export default Employee;
