let addEmployeeAction = (employee) => {
    return async function (dispatch) {
        const res = await fetch(
            "http://localhost:8080/myapp/employee", { 
                method: "POST", 
                body: JSON.stringify({ 
                    name: employee.name, 
                    sal: employee.sal,
                    department: {"deptId": employee.department.deptId}
                }), 
                headers: { 
                    "Content-type": "application/json; charset=UTF-8"
                }
            });
          const data = await res.json();
          dispatch({type: "ADD_EMPLOYEE", payload: data});
    }
}

export default addEmployeeAction;
