let showEmployeesAction = () => {
    return async function (dispatch) {
        const res = await fetch(
            "http://localhost:8080/myapp/employee"
          );
          const data = await res.json();
          dispatch({type: "SHOW_EMPLOYEES", payload: data});
    }
}

export default showEmployeesAction;
