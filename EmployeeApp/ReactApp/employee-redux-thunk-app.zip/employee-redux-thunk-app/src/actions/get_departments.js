let showDepartmentsAction = () => {
    return async function (dispatch) {
        const res = await fetch(
            "http://localhost:8080/myapp/department"
          );
          const data = await res.json();
          console.log("showDepartmentsAction ", data);
          dispatch({type: "SHOW_DEPARTMENTS", payload: data});
    }
}

export default showDepartmentsAction;
