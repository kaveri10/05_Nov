const initialState = [];
const employeeReducer = (state=initialState, action) => {
    switch(action.type) {
        case 'ADD_EMPLOYEE':
            return action.payload;
        case 'SHOW_EMPLOYEES':
            return action.payload;
        case 'SHOW_DEPARTMENTS':
            return action.payload;
        default:
            return [];
    }
}

export default employeeReducer;
