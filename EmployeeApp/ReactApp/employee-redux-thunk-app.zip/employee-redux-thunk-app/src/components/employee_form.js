import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import showDepartmentsAction from '../actions/get_departments';
import addEmployeeAction from '../actions/add_employee';
import { useHistory } from "react-router-dom";
import Employee from '../models/employee';

let dispatch;
let history;
let selectedDeptId;

const EmployeeForm = (props) => {
    dispatch = useDispatch();
    history = useHistory();
    let deptList = useSelector(state => state);

    React.useEffect(() => {
        DepartmentList()
      }, []);
    
      const DepartmentList = () => {
        dispatch(showDepartmentsAction())
      }
    console.log("deptList: ", deptList);

        return (<form onSubmit={handleSubmit}>
        <div><center>
            <h2>Employee Form</h2><br></br>
            <label htmlFor="name">Enter name</label>
            <input id="name" name="name" type="text" />
            <label htmlFor="sal">Enter salary</label>
            <input id="sal" name="sal" type="text" />
            <select id="department" onChange={handleChange}>
                {renderDepartments(deptList)}
            </select>
            <button>ADD</button>
            </center>
        </div>
        </form>);
};

function handleChange(event) {
    selectedDeptId = event.target.value
    console.log("selected department: ", selectedDeptId);
}

function renderDepartments(deptList) {
    console.log("deptList: ", deptList);
    //console.log("deptList[0].deptId: ", deptList[0].deptId);
    return deptList.map((department, index) => {
       const { deptId, name } = department //destructuring
       return (
        <option key={deptId} value={deptId}>{name}</option>
       )
    })
 };

 function handleSubmit(event) {
    event.preventDefault();
    const data = new FormData(event.target);
    const name = data.get('name');
    const sal = data.get('sal');
    if(name==='' || name===null) {
        alert("Name cannot be blank");
        return;
    }
    else if(!Number(sal)) {
        alert("Salary must be a number");
        return;
    }
    const empObj = new Employee(name, sal, selectedDeptId);
    dispatch(addEmployeeAction(empObj));
    history.push('/');
}

export default EmployeeForm;
