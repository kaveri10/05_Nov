import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import showEmployeesAction from '../actions/show_employees';


const ShowEmployees = (props) => {


    let employeeList = useSelector(state => state);

    const dispatch = useDispatch();

    React.useEffect(() => {
        EmployeeList()
      }, []);
    
      const EmployeeList = () => {
        dispatch(showEmployeesAction())
      }
    console.log("employeeList: ", employeeList);
    if(!Array.isArray(employeeList)) {
        employeeList = [];
        console.log("Set employeeList to blank array");
    }
    return (<div>
    <center>
    <h2>Employee List</h2>
    <table border="2">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Salary</th>
            <th>Department</th>
        </tr>
    </thead>
    <tbody>
        {renderTableData(employeeList)}
    </tbody>
    </table>
    </center>
</div>);
};

function renderTableData(employeeList) {
    console.log("employeeList: ", employeeList);
    return employeeList.map((employee, index) => {
        const deptName = employee.department.name;
       const { employeeId, name, sal } = employee //destructuring
       return (
          <tr key={employeeId}>
             <td>{employeeId}</td>
             <td>{name}</td>
             <td>{sal}</td>
             <td>{deptName}</td>
          </tr>
       )
    })
 };

export default ShowEmployees
