import { useDispatch } from 'react-redux';
import addEmployeeAction from '../actions/add_employee';

const AddEmployee = (props) => {
    const dispatch = useDispatch();
    dispatch(addEmployeeAction());
};

export default AddEmployee;
