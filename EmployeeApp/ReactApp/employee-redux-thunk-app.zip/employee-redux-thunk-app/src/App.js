import {  BrowserRouter as Router,  Switch,  Route,  Link } from "react-router-dom";
import ShowEmployees from './components/show';
import EmployeeForm from './components/employee_form';
import Home from './components/home';
import AddEmployee from './components/add_employee';

function App() {
  

  return (
    <Router>
    <div className="App">
      <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/show">Show Employees</Link>
          </li>
          <li>
            <Link to="/add-form">Add Employee</Link>
          </li>
        </ul>

        <hr />

      <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route path="/show">
            <ShowEmployees/>
          </Route>
          <Route path="/add-form">
            <EmployeeForm />
          </Route>
          <Route path="/add">
            <AddEmployee />
          </Route>
        </Switch> 
        </div>       
        </Router>
  );
}

export default App;
